const express = require("express");
const router = express.Router();
const {
  getUsers,
  getUsersById,
  register,
  updateUsers,
  deleteUsers,
  paginate,
  search,
  login,
  updatePass,
} = require("../controllers/Api/UsersController.js");
router.route("/").get(getUsers).post(register);

router.route("/login").post(login);
router.route("/edit-pass").post(updatePass);
router.route("/paginate").post(paginate);
router.route("/search").post(search);
router.route("/:id").get(getUsersById).put(updateUsers).delete(deleteUsers);
module.exports = router;
