const express = require("express");
const router = express.Router();
const {
  getLeactures,
  getLeacturesById,
  createLeactures,
  updateLeactures,
  deleteLeactures,
  paginate,
  search,
} = require("../controllers/Api/LeacturesController.js");
router.route("/").get(getLeactures).post(createLeactures);
router.route("/paginate").post(paginate);
router.route("/search").post(search);
router
  .route("/:id")
  .get(getLeacturesById)
  .put(updateLeactures)
  .delete(deleteLeactures);
module.exports = router;
