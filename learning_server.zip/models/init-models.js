var DataTypes = require("sequelize").DataTypes;
var _categories = require("./categories");
var _leactures = require("./leactures");
var _sub_categories = require("./sub_categories");
var _users = require("./users");

function initModels(sequelize) {
  var categories = _categories(sequelize, DataTypes);
  var leactures = _leactures(sequelize, DataTypes);
  var sub_categories = _sub_categories(sequelize, DataTypes);
  var users = _users(sequelize, DataTypes);

  sub_categories.belongsTo(categories, { as: "category", foreignKey: "category_id"});
  categories.hasMany(sub_categories, { as: "sub_categories", foreignKey: "category_id"});
  leactures.belongsTo(sub_categories, { as: "category", foreignKey: "category_id"});
  sub_categories.hasMany(leactures, { as: "leactures", foreignKey: "category_id"});

  return {
    categories,
    leactures,
    sub_categories,
    users,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
