const express = require("express");
const dotenv = require("dotenv");
dotenv.config({ path: `${__dirname}/.env` });
const cors = require("cors");
// const cookieParser = require("cookie-parser");
// global.loadLocaleMessages = require("locnode");

const fileEasyUpload = require("express-easy-fileuploader");
const file_upload = require("./middleware/media_middleware");
const categories = require("./routes/Categories");

const sub_categories = require("./routes/SubCategories");
const leactures = require("./routes/Leactures.js");
const users = require("./routes/Users.js");
const port = process.env.PORT || 3030;
const app = express();
const bodyParser = require("body-parser");
const { authenticate } = require("./middleware/authenticate.js");
app.use(cors());
app.use(
  fileEasyUpload({
    app,
    fileUploadOptions: {
      limits: { fileSize: 50 * 1024 * 1024 },
    },
  })
);
app.use(bodyParser.json({ limit: "10000mb" }));
app.use(express.static(__dirname + "/public/"));
// app.use(cookieParser());
app.use("/api/static", express.static("uploads"));
app.use(file_upload);
//app.use(authenticate);

app.use("/api/categories", categories);
app.use("/api/sub-categories", sub_categories);
app.use("/api/leactures", leactures);
app.use("/api/users", users);

app.listen(port, () => console.log(`server is running on ,port is  ${port} `));
module.exports = app;
